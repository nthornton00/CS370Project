package login;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax. swing. *;

public class LoginPage {

	private JFrame frame;
	private JTextField username;
	private JPasswordField password;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginPage window = new LoginPage();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public LoginPage() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(128, 128, 128));
		frame.setBackground(new Color(255, 255, 255));
		frame.setBounds(100, 100, 650, 570);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel pass = new JPanel();
		pass.setBounds(0, 283, 634, 248);
		frame.getContentPane().add(pass);
		pass.setLayout(null);
		
		username = new JTextField();
		username.setBounds(318, 57, 140, 30);
		pass.add(username);
		username.setColumns(10);
		
		password = new JPasswordField();
		password.setBounds(318, 100, 140, 30);
		pass.add(password);
		
		JLabel lblNewLabel = new JLabel("Username");
		lblNewLabel.setFont(new Font("Arial", Font.PLAIN, 16));
		lblNewLabel.setBounds(143, 57, 98, 30);
		pass.add(lblNewLabel);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Arial", Font.PLAIN, 16));
		lblPassword.setBounds(143, 100, 98, 30);
		pass.add(lblPassword);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String u_name = username.getText();
				String p_word = password.getText();
				
				if(u_name.equals("test") && p_word.equals("123")) {
					JOptionPane.showMessageDialog(null, "Login Successful");
				}
				else {
					JOptionPane.showMessageDialog(null, "Login Unsuccessful");
				}
				
				
			}
		});
		btnNewButton.setFont(new Font("Arial", Font.PLAIN, 16));
		btnNewButton.setBounds(250, 170, 103, 30);
		pass.add(btnNewButton);
	}
}
